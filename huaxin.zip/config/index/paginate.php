<?php
//分页配置
return [
    'type'     => '\page\Pc',
    'var_page' => 'page',
];