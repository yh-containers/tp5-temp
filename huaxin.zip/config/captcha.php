<?php
return [
    'codeSet'   => '0123456789',
    'length'    => 4,
    'useNoise'  => false,
    'useCurve'  => false,
];