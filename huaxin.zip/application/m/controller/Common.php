<?php
namespace app\m\controller;
use think\Controller;

class Common extends Controller{

}