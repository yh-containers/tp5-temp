<?php /*a:2:{s:77:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\article\solution.html";i:1563793822;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>



<?php echo widget('Component/header',['act_menu'=>'article/solution']); ?>
    <div class="nybanner">
        <p><img src="<?php echo htmlentities($cate['img']); ?>"></p>
    </div>
    
    <div class="main">
        <div class="inside_title">
            <h2>解决方案</h2>
            <p>SOLUTION</p>
        </div>
        <div class="inside_sort">
            <select onchange="changePage(this)">
                <?php if(is_array($cate['link_child']) || $cate['link_child'] instanceof \think\Collection || $cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option  value="<?php echo htmlentities($vo['id']); ?>" <?php echo $vo['id']==$current_cate['id']?'selected':''; ?>><?php echo htmlentities($vo['name']); ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
        </div>
        <div class="solution">
            <div class="info">
                <div class="title"><?php echo htmlentities($current_cate['name']); ?></div>
                <div class="text">
                    <?php echo htmlentities($current_cate['desc']); ?>
                </div>
            </div>
            <div class="advantage">
                <div class="title">方案优势</div>
                <ul class="clearfix">
                    <li>
                        <div class="img"><img src="/assets/m/images/solution05.jpg"></div>
                        <div class="text">
                            <i><img src="/assets/m/images/icon17.png"></i>
                            <h2>互联互通</h2>
                            <p>通过子系统之间互联互通实现设备之间直接对话</p>
                        </div>
                    </li>
                    <li>
                        <div class="img"><img src="/assets/m/images/solution06.jpg"></div>
                        <div class="text">
                            <i><img src="/assets/m/images/icon18.png"></i>
                            <h2>数据共享</h2>
                            <p>通过数据的集中存储和管理实现数据共享</p>
                        </div>
                    </li>
                    <li>
                        <div class="img"><img src="/assets/m/images/solution07.jpg"></div>
                        <div class="text">
                            <i><img src="/assets/m/images/icon19.png"></i>
                            <h2>响应及时</h2>
                            <p>通过大数据的分析与处理实现场景的及时有效控制</p>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="application">
                <div class="title">应用场景</div>
                <ul class="clearfix">
                    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <li>
                        <a href="<?php echo url('solutionDetail',['id'=>$vo['id']]); ?>">
                            <div class="img"><img src="<?php echo htmlentities($vo['img']); ?>"></div>
                            <div class="name"><?php echo htmlentities($vo['title']); ?></div>
                        </a>
                    </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="footer wrap">
       <p>Copyright © 2019　版权所有　深圳市华新网络能源有限公司 All Rights Reserved 　<a href="http://www.miibeian.gov.cn/">备案号：粤ICP8888888</a></p>
    </div>

<?php echo widget('Component/footer'); ?>


</body>
</html>


<script>
    function changePage(obj){
        location.href="<?php echo url('article/solution'); ?>?cid="+$(obj).val()
    }
</script>
