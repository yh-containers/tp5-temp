<?php /*a:2:{s:66:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\error.html";i:1563591200;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>

<style>
	.error{font-size: 26px;text-align: center;color:orange;padding: 100px;}
</style>




<?php echo widget('Component/header',['act_menu'=>'index']); ?>
<div class="error"><?php echo htmlentities($msg); ?></div>
<?php echo widget('Component/footer',['act_menu'=>'index']); ?>



</body>
</html>


<script type="text/javascript" src="/assets/index/js/wow.min.js"></script>
<script language="javascript" type="text/javascript" src="/assets/index/js/jquery.waypoints.min.js"></script>



<script type="text/javascript">
	/* banner切换 */
	jQuery(".banner").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click",
	});

	/*产品多页签*/
	jQuery(".pro_list").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold",trigger:"click"});

	/*方案多页签*/
	jQuery(".case_tabs").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold",trigger:"click"});

	/*案例滚动*/
	jQuery(".case_left").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"left",autoPlay:true,vis:4,trigger:"click",scroll:"4"});

	/*新闻多页签*/
	jQuery(".news_tabs").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold"});
</script>

<script>
	if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
		new WOW().init();
	};
</script>

<!-- 数字跳动 -->
<script type="text/javascript">
	$('.index_about .num span,.index_num .num span').countUp({
		delay: 10,
		time: 2000
	});

</script>
