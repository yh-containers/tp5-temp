<?php /*a:2:{s:79:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\article\newsDetail.html";i:1563792577;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>




<?php echo widget('Component/header',['act_menu'=>'article/news']); ?>
    <div class="nybanner">
        <p><img src="<?php echo htmlentities($current_cate['img']); ?>"></p>
    </div>
    
    <div class="main">
        <div class="inside_title">
            <h2>关于我们</h2>
            <p>ABOUT US</p>
        </div>
        <div class="inside_sort">
            <select onchange="changePage(this)">
                <?php if(is_array($cate['link_child']) || $cate['link_child'] instanceof \think\Collection || $cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option  value="<?php echo htmlentities($vo['id']); ?>" <?php echo $vo['id']==$current_cate['id']?'selected':''; ?>><?php echo htmlentities($vo['name']); ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
        </div>
        <div class="news_det">
            <div class="news_title">
                <h2><?php echo htmlentities($model['title']); ?></h2>
                <p><span>时间：<?php echo substr($model['update_time'],0,10); ?></span><span>来源：<?php echo htmlentities($model['from']); ?></span><span>浏览：<?php echo htmlentities($model['views']); ?></span></p>
            </div>
            <div class="news_content">
                <?php echo htmlspecialchars_decode($model['content']); ?>
            </div>
            <?php echo widget('component/share'); ?>
            <div class="page_turning clearfix">
                <div class="page_left">
                    <p><a href="<?php echo url('',['id'=>$model_up['id']]); ?>">上一篇：<?php echo htmlentities($model_up['title']); ?></a></p>
                    <p><a href="<?php echo url('',['id'=>$model_down['id']]); ?>">下一篇：<?php echo htmlentities($model_down['title']); ?></a></p>
                </div>
            </div>
        </div>
    </div>

    <div class="footer wrap">
       <p>Copyright © 2019　版权所有　深圳市华新网络能源有限公司 All Rights Reserved 　<a href="http://www.miibeian.gov.cn/">备案号：粤ICP8888888</a></p>
    </div>

<?php echo widget('Component/footer'); ?>


</body>
</html>


<script>
    function changePage(obj){
        location.href="<?php echo url('article/solution'); ?>?cid="+$(obj).val()
    }
</script>
