<?php /*a:2:{s:80:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\article\certAdd.html";i:1563450254;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\base.html";i:1563530573;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo config('app_name'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/assets/bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="/assets/bower_components/Ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/assets/dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="/assets/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="/assets/layui-v.2.5.4/css/layui.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo url('index/index'); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b><?php echo config('app_name'); ?></b></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b><?php echo config('app_name'); ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- Messages: style can be found in dropdown.less-->
                    <!-- Notifications: style can be found in dropdown.less -->
                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs"><?php echo session('user_name'); ?></span>
                        </a>
                    </li>
                    <!-- Control Sidebar Toggle Button -->
                    <li>
                        <a href="<?php echo url('index/logout'); ?>">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            <span class="hidden-xs">退出登录</span>
                        </a>
                    </li>
                    <li></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">

            </div>
            <!--高亮选中-->
            <?php 
                $current_index = "article,article/cert";
                $current_index = empty($current_index)?[]:explode(',', $current_index);
             ?>
            <!-- /.search form -->
           <?php echo widget('Components/menu',['current_index'=>$current_index]); ?>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <!--<section class="content-header">
            <h1>
                404 Error Page
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">404 error</li>
            </ol>
        </section>-->

        <!-- Main content -->
        <section class="content">
            

    <div class="box box-primary">
        <div class="box-header with-border">
            <!--<h3 class="box-title">Quick Example</h3>-->
        </div>
        <!-- /.box-header -->
        <!-- form start -->
            <div class="box-body">
                <form id="form" action="" class="form-horizontal">
                    <input type="hidden" name="id" value="<?php echo htmlentities($model['id']); ?>"/>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">名称</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="名称" name="name" value="<?php echo htmlentities($model['name']); ?>" maxlength="100">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">证书图片</label>
                        <div class="col-sm-10">
                            <input type="hidden" name="img" value="<?php echo htmlentities($model['img']); ?>" />
                            <button type="button" class="layui-btn upload-img" lay-data="{ url: '<?php echo url('upload/upload',['type'=>'partner']); ?>', accept: 'images'}">
                                <i class="layui-icon">&#xe67c;</i>证书图片
                            </button>
                            <img width="80" height="80" src="<?php echo htmlentities($model['img']); ?>" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">排序</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" placeholder="排序" name="sort" value="<?php echo empty($model['sort'])?100:$model['sort']; ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">状态</label>
                        <div class="col-sm-10">
                            <label>
                                <input type="radio" name="status" value="1" <?php echo $model['status']!=2?'checked':''; ?> />
                                正常
                            </label>
                            <label>
                                <input type="radio" name="status" value="2" <?php echo $model['status']==2?'checked':''; ?>>
                                关闭
                            </label>
                        </div>
                    </div>
                </form>

            </div>
            <!-- /.box-body -->

        <div class="box-footer">
            <button type="button" onclick="$.common.submitForm()" class="col-sm-offset-2 btn  btn-info">保存</button>
        </div>
    </div>


        </section>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 2.4.0
        </div>
        <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="/assets/bower_components/jquery/dist/jquery.min.js"></script>

<script src="/assets/layui-v.2.5.4/layui.js"></script>

<!-- Bootstrap 3.3.7 -->
<script src="/assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="/assets/bower_components/fastclick/lib/fastclick.js"></script>
<script src="/assets/dist/js/adminlte.min.js"></script>
<script src="/assets/admin/js/common.js"></script>


<script>
    //引用上传组件
    layui.use(['upload'],function(){
        var upload = layui.upload;
        $.common.fileUpload(upload,'.upload-img')
    })
</script>


</body>
</html>
