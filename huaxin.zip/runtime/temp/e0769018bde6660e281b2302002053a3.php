<?php /*a:2:{s:74:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\common\header.html";i:1563797369;s:74:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\article\share.html";i:1563586172;}*/ ?>
<div class="bdsharebuttonbox">
    <a href="#" class="bds_more" data-cmd="more"></a>
    <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
    <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
    <a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
    <a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
    <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
</div>