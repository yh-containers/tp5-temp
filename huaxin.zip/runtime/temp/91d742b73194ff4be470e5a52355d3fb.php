<?php /*a:2:{s:76:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\index\index.html";i:1563855016;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\base.html";i:1563521072;}*/ ?>
<!DOCTYPE html>
<html lang="CN">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="shortcut icon" href="/assets/index/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/assets/index/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/index/css/css.css"/>
    <script type="text/javascript" src="/assets/index/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/assets/index/js/jquery.SuperSlide.2.1.1.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>


<?php echo widget('Component/header',['act_menu'=>'index']); ?>
	<div class="banner">
		<div class="bd">
			<ul>
				<?php if(is_array($flow_img) || $flow_img instanceof \think\Collection || $flow_img instanceof \think\Paginator): $i = 0; $__LIST__ = $flow_img;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li><img src="<?php echo htmlentities($vo['img']); ?>"></li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
		<div class="hd"><ul></ul></div>
	</div>
	
	<div class="main">
		<div class="index_num">
			<ul class="w1200 clearfix">
				<li>
					<div class="num"><span>100</span><em>+</em></div>
					<p>产品/组</p>
				</li>
				<li>
					<div class="num"><span>1000</span><em>+</em></div>
					<p>案例/款</p>
				</li>
				<li>
					<div class="num"><span>8</span><em>+</em></div>
					<p>经验/年</p>
				</li>
				<li>
					<div class="num"><span>500</span><em>+</em></div>
					<p>合作伙伴</p>
				</li>
			</ul>
		</div>
		<div class="index_pro">
			<div class="pro_title w1200">
				<h2>安全、稳定、可信赖的工业物联网产品</h2>
				<p><?php echo htmlentities($product_cate['desc']); ?></p>
			</div>
			<div class="pro_list w1200 clearfix">
				<div class="hd wow fadeInLeft">
					<ul>
						<?php if(is_array($product_cate['link_child']) || $product_cate['link_child'] instanceof \think\Collection || $product_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $product_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<li>
							<div class="title">
								<h2><?php echo htmlentities($vo['name']); ?></h2>
								<p>产品型号齐全</p>
							</div>
						</li>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
				</div>
				<div class="bd wow fadeInRight">
					<div class="conWrap">
						<?php if(is_array($product_cate['link_child']) || $product_cate['link_child'] instanceof \think\Collection || $product_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $product_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<div class="con">
							<p><img src="<?php echo htmlentities($vo['img']); ?>"></p>
							<h2><?php echo htmlentities($vo['name']); ?></h2>
							<p><?php echo htmlentities($vo['desc']); ?></p>
							<a href="<?php echo url('product/index',['cid'=>$vo['id']]); ?>">查看详情</a>
						</div>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</div>
				</div>
			</div>
		</div>
		<div class="index_case w1200">
			<div class="index_title">
				<h2>成功案例</h2>
				<p><?php echo htmlentities($case_cate['desc']); ?></p>
			</div>
			<div class="case_left">
				<div class="bd">
					<ul class="picList">
						<?php if(is_array($case_cate['link_case']) || $case_cate['link_case'] instanceof \think\Collection || $case_cate['link_case'] instanceof \think\Paginator): $i = 0; $__LIST__ = $case_cate['link_case'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<li>
							<a href="<?php echo url('article/casesDetail',['id'=>$vo['id']]); ?>">
								<div class="img"><img src="<?php echo htmlentities($vo['img']); ?>"></div>
								<div class="title"><?php echo htmlentities($vo['title']); ?></div>
							</a>
						</li>
						<?php endforeach; endif; else: echo "" ;endif; ?>

					</ul>
				</div>
				<div class="hd">
					<ul></ul>
				</div>
			</div>
		</div>
		<div class="index_solution">
			<div class="index_title w1200">
				<h2>解决方案</h2>
				<p><?php echo htmlentities($solution_cate['desc']); ?></p>
			</div>
			<div class="case_tabs">
				<div class="hd w1200">
					<ul class="clearfix">
						<?php if(is_array($solution_cate['link_child']) || $solution_cate['link_child'] instanceof \think\Collection || $solution_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $solution_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<li>
							<i class="icon"><img src="<?php echo htmlentities($vo['icon']); ?>"></i>
							<i class="icon2"><img src="<?php echo htmlentities($vo['icon2']); ?>"></i>
							<p><?php echo htmlentities($vo['name']); ?></p>
						</li>
						<?php endforeach; endif; else: echo "" ;endif; ?>

					</ul>
				</div>
				<div class="bd">
					<div class="conWrap">

						<?php if(is_array($solution_cate['link_child']) || $solution_cate['link_child'] instanceof \think\Collection || $solution_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $solution_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<div class="con">
							<div class="img" style="background-image:url(<?php echo htmlentities($vo['img']); ?>);"></div>
							<div class="content">
								<div class="text w1200">
									<h2><?php echo htmlentities($vo['name']); ?>解决方案</h2>
									<p><?php echo htmlentities($vo['desc']); ?></p>
									<a href="<?php echo url('article/solution',['id'=>$vo['id']]); ?>">了解更多</a>
								</div>
							</div>
						</div>

						<?php endforeach; endif; else: echo "" ;endif; ?>

					</div>
				</div>
			</div>
		</div>
		<div class="index_news">
			<div class="index_title w1200">
				<h2>新闻资讯</h2>
				<p><?php echo htmlentities($news_cate['desc']); ?></p>
			</div>
			<div class="news_tabs w1200">
				<div class="hd">
					<ul>
						<?php if(is_array($news_cate['link_child']) || $news_cate['link_child'] instanceof \think\Collection || $news_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $news_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							<li><?php echo htmlentities($vo['name']); ?></li>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
				</div>
				<div class="bd">
					<div class="conWrap">
						<?php if(is_array($news_cate['link_child']) || $news_cate['link_child'] instanceof \think\Collection || $news_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $news_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<div class="con">
							<ul class="clearfix">
								<?php if(is_array($vo['link_news']) || $vo['link_news'] instanceof \think\Collection || $vo['link_news'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['link_news'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$news): $mod = ($i % 2 );++$i;?>

								<li>
									<a href="<?php echo url('article/newsDetail',['id'=>$news['id']]); ?>">
										<div class="img"><img src="<?php echo htmlentities($news['img']); ?>"></div>
										<div class="title">
											<h2><?php echo htmlentities($news['title']); ?></h2>
											<p>时间：<?php echo substr($news['show_time'],0,10); ?></p>
										</div>
										<div class="text">
											<p><?php echo htmlentities($news['intro']); ?></p>
											<h3>查看详情</h3>
										</div>
									</a>
								</li>
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</ul>
						</div>
						<?php endforeach; endif; else: echo "" ;endif; ?>

					</div>
				</div>
			</div>
		</div>
		<div class="index_about">
			<div class="w1200">
				<dl>
					<dt>深圳市华新网络能源有限公司</dt>
					<dd>
						<p>深圳市华新网络能源有限公司，成立于2014年，是一家集设备能源管控平台、暖通空调自控、工业设备互联、工
						<p>厂智能等解决方案设计、工程实施、运营管理于一体的综合节能服务商。深圳华新主要业务范围及服务领域包括设备能源管控系统、工业装备互联</p>
						<p>网接入设备的产品设计开发及智慧工厂解决方案</p> 
						</p>
					</dd>
				</dl>
				<ul class="clearfix">
					<li>
						<div class="num"><span>2014</span><em>年</em></div>
						<p>创建于</p>
					</li>
					<li>
						<div class="num"><span>3000</span><em>家</em></div>
						<p>服务客户</p>
					</li>
					<li>
						<div class="num"><span>99</span><em>%</em></div>
						<p>好评度</p>
					</li>
					<li>
						<div class="num"><span>5</span><em>年</em></div>
						<p>行业经验</p>
					</li>
				</ul>
				<a href="about.html">了解华新智控 &gt;</a>
			</div>
		</div>
	</div>

<?php echo widget('Component/footer',['act_menu'=>'index']); ?>



</body>
</html>


<script type="text/javascript" src="/assets/index/js/wow.min.js"></script>
<script language="javascript" type="text/javascript" src="/assets/index/js/jquery.waypoints.min.js"></script>



<script type="text/javascript">
	/* banner切换 */
	jQuery(".banner").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click",
	});

	/*产品多页签*/
	jQuery(".pro_list").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold",trigger:"click"});

	/*方案多页签*/
	jQuery(".case_tabs").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold",trigger:"click"});

	/*案例滚动*/
	jQuery(".case_left").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"left",autoPlay:true,vis:4,trigger:"click",scroll:"4"});

	/*新闻多页签*/
	jQuery(".news_tabs").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold"});
</script>

<script>
	if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
		new WOW().init();
	};
</script>

<!-- 数字跳动 -->
<script type="text/javascript">
	$('.index_about .num span,.index_num .num span').countUp({
		delay: 10,
		time: 2000
	});

</script>
