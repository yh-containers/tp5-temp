<?php /*a:1:{s:78:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\common\footer.html";i:1563521072;}*/ ?>
<div class="footer">
    <div class="w1200">
        <div class="partner wow fadeInUp">
            <h2>合作伙伴</h2>
            <ul class="clearfix">
                <?php if(is_array($partner) || $partner instanceof \think\Collection || $partner instanceof \think\Paginator): $i = 0; $__LIST__ = $partner;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <li><a href="<?php echo url($vo['url']); ?>"><img src="<?php echo htmlentities($vo['img']); ?>"></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        <div class="footer_sort clearfix wow fadeInUp">
            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <dl>
                <dt><a href="<?php echo url($vo['url']); ?>"><?php echo htmlentities($vo['name']); ?></a></dt>
                <?php if(is_array($vo['link_child']) || $vo['link_child'] instanceof \think\Collection || $vo['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$child): $mod = ($i % 2 );++$i;?>
                <dd><a href="<?php echo url($child['url']); ?>"><?php echo htmlentities($child['name']); ?></a></dd>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </dl>
            <?php endforeach; endif; else: echo "" ;endif; ?>

            <div class="footer_ewm">
                <h2>产品资讯热线</h2>
                <p><?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'hot_tel']); ?></p>
                <p><img src="<?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'qr_code']); ?>" width="120" height="120"></p>
                <ul class="clearfix">
                    <li><a href=""><img src="/assets/index/images/qq.png"></a></li>
                    <li>
                        <a href="javascript:;"><img src="/assets/index/images/wx.png"></a>
                        <div class="wx_ewm"><img src="<?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'qr_code_wx']); ?>"></div>
                    </li>
                    <li><a href=""><img src="/assets/index/images/wb.png"></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer_copyright">
        <p class="wow fadeInUp"><?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'icp']); ?></p>
    </div>
</div>