<?php /*a:2:{s:79:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\system\setting.html";i:1563589494;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\base.html";i:1563530573;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo config('app_name'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/assets/bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="/assets/bower_components/Ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/assets/dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="/assets/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="/assets/layui-v.2.5.4/css/layui.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo url('index/index'); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b><?php echo config('app_name'); ?></b></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b><?php echo config('app_name'); ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- Messages: style can be found in dropdown.less-->
                    <!-- Notifications: style can be found in dropdown.less -->
                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs"><?php echo session('user_name'); ?></span>
                        </a>
                    </li>
                    <!-- Control Sidebar Toggle Button -->
                    <li>
                        <a href="<?php echo url('index/logout'); ?>">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            <span class="hidden-xs">退出登录</span>
                        </a>
                    </li>
                    <li></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">

            </div>
            <!--高亮选中-->
            <?php 
                $current_index = "system,system/setting";
                $current_index = empty($current_index)?[]:explode(',', $current_index);
             ?>
            <!-- /.search form -->
           <?php echo widget('Components/menu',['current_index'=>$current_index]); ?>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <!--<section class="content-header">
            <h1>
                404 Error Page
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">404 error</li>
            </ol>
        </section>-->

        <!-- Main content -->
        <section class="content">
            
    <div class="row">
        <div class="col-sm-6">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h4 class="box-title">常规设置</h4>
                    <button type="button" onclick="$.common.submitForm($('#form-normal'),1)" class="col-sm-offset-2 btn btn-sm btn-warning pull-right">保存</button>
                </div>
                <div class="box-body">
                    <form id="form-normal" action="<?php echo url('settingSave'); ?>" class="form-horizontal">
                        <input type="hidden" name="type" value="normal"/>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">地址</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="地址" name="content[addr]" value="<?php echo isset($normal_content['addr'])?$normal_content['addr']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">传真</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="传真" name="content[fax]" value="<?php echo isset($normal_content['fax'])?$normal_content['fax']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">资讯热线</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="资讯热线" name="content[hot_tel]" value="<?php echo isset($normal_content['hot_tel'])?$normal_content['hot_tel']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">客服电话</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="客服电话" name="content[tel]" value="<?php echo isset($normal_content['tel'])?$normal_content['tel']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">产品资讯联系人</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="产品资讯联系人" name="content[product_person]" value="<?php echo isset($normal_content['product_person'])?$normal_content['product_person']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">产品资讯</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="产品资讯" name="content[product_tel]" value="<?php echo isset($normal_content['product_tel'])?$normal_content['product_tel']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">邮箱</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="email" name="content[email]" value="<?php echo isset($normal_content['email'])?$normal_content['email']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">qq</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="qq" name="content[qq]" value="<?php echo isset($normal_content['qq'])?$normal_content['qq']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">微博</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="wb" name="content[wb]" value="<?php echo isset($normal_content['wb'])?$normal_content['wb']:''; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">二维码</label>
                            <div class="col-sm-10">
                                <input type="hidden" name="content[qr_code]" value="<?php echo isset($normal_content['qr_code'])?$normal_content['qr_code']:''; ?>" />
                                <button type="button" class="layui-btn upload-img" lay-data="{ url: '<?php echo url('upload/upload',['type'=>'sys-normal']); ?>', accept: 'images'}">
                                    <i class="layui-icon">&#xe67c;</i>二维码
                                </button>
                                <img width="80" height="80" src="<?php echo isset($normal_content['qr_code'])?$normal_content['qr_code']:''; ?>"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">微信二维码</label>
                            <div class="col-sm-10">
                                <input type="hidden" name="content[qr_code_wx]" value="<?php echo isset($normal_content['qr_code_wx'])?$normal_content['qr_code_wx']:''; ?>" />
                                <button type="button" class="layui-btn upload-img" lay-data="{ url: '<?php echo url('upload/upload',['type'=>'sys-normal']); ?>', accept: 'images'}">
                                    <i class="layui-icon">&#xe67c;</i>微信二维码
                                </button>
                                <img width="80" height="80" src="<?php echo isset($normal_content['qr_code_wx'])?$normal_content['qr_code_wx']:''; ?>" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">备案信息</label>
                            <div class="col-sm-10">
                                <textarea name="content[icp]" class="form-control" rows="5"><?php echo isset($normal_content['icp'])?$normal_content['icp']:''; ?></textarea>
                            </div>
                        </div>

                    </form>
                </div>
            </div>


        </div>
        <div class="col-sm-6 no-padding">

            <div class="box box-primary">
                <div class="box-header with-border">
                    <h4 class="box-title">其它设置</h4>
                    <button type="button" onclick="$.common.submitForm($('#form-other'),1)" class="col-sm-offset-2 btn btn-sm btn-warning pull-right">保存</button>
                </div>
                <div class="box-body">
                    <form id="form-other" action="<?php echo url('settingSave'); ?>" class="form-horizontal">
                        <input type="hidden" name="type" value="other"/>


                        <div class="form-group">
                            <label class="col-sm-2 control-label">产品热门关键字</label>
                            <div class="col-sm-10">
                                <textarea name="content[product_hot_key]" class="form-control" rows="5"><?php echo isset($other_content['product_hot_key'])?$other_content['product_hot_key']:''; ?></textarea>
                                <span class="help-block text-red">一行一个关键字</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">meta关键字</label>
                            <div class="col-sm-10">
                                <textarea name="content[meta_key]" class="form-control" rows="5"><?php echo isset($other_content['meta_key'])?$other_content['meta_key']:''; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">meta描述</label>
                            <div class="col-sm-10">
                                <textarea name="content[meta_desc]" class="form-control" rows="5"><?php echo isset($other_content['meta_desc'])?$other_content['meta_desc']:''; ?></textarea>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>


        </section>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 2.4.0
        </div>
        <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="/assets/bower_components/jquery/dist/jquery.min.js"></script>

<script src="/assets/layui-v.2.5.4/layui.js"></script>

<!-- Bootstrap 3.3.7 -->
<script src="/assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="/assets/bower_components/fastclick/lib/fastclick.js"></script>
<script src="/assets/dist/js/adminlte.min.js"></script>
<script src="/assets/admin/js/common.js"></script>


<script>
    //引用上传组件
    layui.use(['upload'],function(){
        var upload = layui.upload;
        $.common.fileUpload(upload,'.upload-img')
    })


</script>


</body>
</html>
