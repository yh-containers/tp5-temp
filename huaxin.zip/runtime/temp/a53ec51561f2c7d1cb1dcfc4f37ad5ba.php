<?php /*a:2:{s:79:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\product\detail.html";i:1563586172;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\base.html";i:1563521072;}*/ ?>
<!DOCTYPE html>
<html lang="CN">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="shortcut icon" href="/assets/index/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/assets/index/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/index/css/css.css"/>
    <script type="text/javascript" src="/assets/index/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/assets/index/js/jquery.SuperSlide.2.1.1.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>


<?php echo widget('Component/header',['act_menu'=>'product/index']); ?>
<div class="nybanner">
	<div class="det_img w1200 clearfix">
		<div class="text">
			<h2><?php echo htmlentities($model['name']); ?></h2>
			<p><?php echo htmlentities($model['desc']); ?></p>
		</div>
		<div class="img"><img src="<?php echo htmlentities($model['img']); ?>"></div>
	</div>
</div>

<div class="main">
	<div class="inside_top w1200">
		<div class="title wow fadeInUp">
			<h2>产品中心<span>PRODUCTS</span></h2>
		</div>
		<div class="column clearfix wow fadeInUp">
			<ul>
				<?php if(is_array($cate['link_child']) || $cate['link_child'] instanceof \think\Collection || $cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li class="<?php echo $vo['id']==$current_cate['id']?'cur':''; ?>"><a href="<?php echo url('',['cid'=>$vo['id']]); ?>"><?php echo htmlentities($vo['name']); ?></a></li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			<div class="bread_crumbs">
				<p>您当前的位置：<a href="<?php echo url('index/index'); ?>">首页</a>
					<span>&gt;</span><a href="<?php echo url('product/index'); ?>"><?php echo htmlentities($cate['name']); ?></a>
					<?php if((!empty($current_cate))): ?>
					<span>&gt;</span><a href="<?php echo url('product/index',['cid'=>$current_cate['id']]); ?>"><?php echo htmlentities($current_cate['name']); ?></a>
					<?php endif; ?>
				</p>
			</div>
		</div>
	</div>
	<div class="products_det w1200">
		<div class="content">
			<?php if(is_array($model['intro']) || $model['intro'] instanceof \think\Collection || $model['intro'] instanceof \think\Paginator): $i = 0; $__LIST__ = $model['intro'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<div class="title"><?php echo htmlentities($vo['name']); ?></div>
			<div class="text">
				<?php if(($vo['ipt_type']=='file')): if((!empty(\app\common\model\BaseModel::checkImg($vo['content'])))): ?>
						<img src="<?php echo htmlentities($vo['content']); ?>">
					<?php else: ?>
						<a href="<?php echo htmlentities($vo['content']); ?>" target="_blank">查看</a>
					<?php endif; else: ?>
					<?php echo htmlentities($vo['content']); ?>
				<?php endif; ?>
			</div>
			<?php endforeach; endif; else: echo "" ;endif; ?>

		</div>
		<div class="related_products">
			<div class="title"><h2>相关产品</h2></div>
			<ul class="clearfix">
				<?php if(is_array($up_list) || $up_list instanceof \think\Collection || $up_list instanceof \think\Paginator): $i = 0; $__LIST__ = $up_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li>
					<a href="<?php echo url('product/detail',['id'=>$vo['id']]); ?>">
						<div class="img"><img src="<?php echo htmlentities($vo['img']); ?>"></div>
						<div class="name"><?php echo htmlentities($vo['name']); ?><span>&gt;</span></div>
					</a>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
	</div>
</div>
<?php echo widget('Component/footer',['act_menu'=>'product/index']); ?>


</body>
</html>




	<script>
		if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
			new WOW().init();
		};
	</script>
