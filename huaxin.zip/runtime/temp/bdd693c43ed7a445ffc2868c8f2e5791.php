<?php /*a:1:{s:74:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\common\footer.html";i:1563781497;}*/ ?>
<div class="suspension">
    <div title="返回顶部" id="toTop" class="default-transition"><img src="/assets/m/images/top_icon.png"/></div>
</div>
<div class="footer_nav">
    <ul class="clearfix">
        <li><a href="<?php echo url('index/index'); ?>"><em><img src="/assets/m/images/icon01.png"></em><span>首页</span></a></li>
        <li><a href="<?php echo url('article/about'); ?>"><em><img src="/assets/m/images/icon02.png"></em><span>关于我们</span></a></li>
        <li><a href="<?php echo url('product/index'); ?>"><em><img src="/assets/m/images/icon03.png"></em><span>产品中心</span></a></li>
        <li><a href="tel:12345678966"><em><img src="/assets/m/images/icon04.png"></em><span>电话咨询</span></a></li>
    </ul>
</div>