<?php /*a:2:{s:78:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\article\cases.html";i:1563586172;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\base.html";i:1563521072;}*/ ?>
<!DOCTYPE html>
<html lang="CN">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="shortcut icon" href="/assets/index/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/assets/index/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/index/css/css.css"/>
    <script type="text/javascript" src="/assets/index/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/assets/index/js/jquery.SuperSlide.2.1.1.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>


<?php echo widget('Component/header',['act_menu'=>'article/cases']); ?>
	<div class="nybanner">
		<p><img src="<?php echo htmlentities($cate['img']); ?>"></p>
	</div>
	
	<div class="main">
		<div class="inside_top w1200">
			<div class="title wow fadeInUp">
				<h2>产品中心<span>PRODUCTS</span></h2>
			</div>
			<div class="column clearfix wow fadeInUp">
				<ul>
					<?php if(is_array($cate['link_child']) || $cate['link_child'] instanceof \think\Collection || $cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
					<li class="<?php echo $vo['id']==$cid?'cur':''; ?>"><a href="<?php echo url('',['cid'=>$vo['id']]); ?>"><?php echo htmlentities($vo['name']); ?></a></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
				<div class="bread_crumbs">
					<p>您当前的位置：<a href="<?php echo url('index/index'); ?>">首页</a>
						<span>&gt;</span><a href="<?php echo url('article/cases'); ?>"><?php echo htmlentities($cate['name']); ?></a>
						<?php if((!empty($current_cate))): ?>
						<span>&gt;</span><a href="javascript:;"><?php echo htmlentities($current_cate['name']); ?></a>
						<?php endif; ?>
					</p>
				</div>
			</div>
		</div>
		<div class="case w1200">
			<ul class="clearfix">
				<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li class="wow fadeInUp">
					<a href="<?php echo url('casesDetail',['id'=>$vo['id']]); ?>">
						<div class="img"><img src="<?php echo htmlentities($vo['img']); ?>"></div>
						<div class="title"><?php echo htmlentities($vo['title']); ?></div>
						<div class="text">
							<h3><?php echo htmlentities($vo['title']); ?></h3>
							<p><?php echo htmlentities($vo['intro']); ?></p>
							<span>查看案例</span>
						</div>
					</a>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>

			</ul>
			<!--分页-->
			<?php echo $page; ?>
		</div>
	</div>
<?php echo widget('Component/footer',['act_menu'=>'product/index']); ?>


</body>
</html>



