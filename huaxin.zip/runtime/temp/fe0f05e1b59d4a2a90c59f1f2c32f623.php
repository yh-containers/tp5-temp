<?php /*a:2:{s:79:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\article\technology.html";i:1563793115;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>




<?php echo widget('Component/header',['act_menu'=>'article/technology']); ?>
<div class="nybanner">
	<p><img src="<?php echo htmlentities($cate['img']); ?>"></p>
</div>

<div class="main">
	<div class="inside_title">
		<h2><?php echo htmlentities($cate['name']); ?><span><?php echo htmlentities($cate['en']); ?></span></h2>
		<p>SUPPORT</p>
	</div>
	<div class="inside_sort">
		<select onchange="changePage(this)">
			<option value="technology.html" selected="selected">技术支持</option>
		</select>
	</div>

	<div class="support w1200">
		<div class="document">
			<div class="title">
				<h2>支持与文档</h2>
				<p>SUPPORT WITH THE DOCUMENT</p>
			</div>
			<ul class="clearfix">
				<li>
					<a href="<?php echo url('resource/index'); ?>">
						<div class="img"><img src="/assets/index/images/icon09.png"></div>
						<div class="text">
							<h3>帮助文档</h3>
							<p>海量产品文档</p>
						</div>
					</a>
				</li>
				<li>
					<a href="tencent://message/?uin=<?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'tel']); ?>">
						<div class="img"><img src="/assets/index/images/icon10.png"></div>
						<div class="text">
							<h3>在线咨询</h3>
							<p>在线为您解答疑惑</p>
						</div>
					</a>
				</li>
				<li>
					<a href="javascript:;">
						<div class="img"><img src="/assets/index/images/icon11.png"></div>
						<div class="text">
							<h3>24小时服务热线</h3>
							<p><?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'tel']); ?></p>
						</div>
					</a>
				</li>
				<li>
					<a href="javascript:;">
						<div class="img"><img src="/assets/index/images/icon12.png"></div>
						<div class="text">
							<h3>产品咨询 <?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'product_person']); ?></h3>
							<p><?php echo widget('Component/getSysSetting',['type'=>'normal','field'=>'hot_tel']); ?></p>
						</div>
					</a>
				</li>
			</ul>
		</div>
		<div class="problem">
			<div class="title">
				<h2>常见问题</h2>
				<p>COMMON PROBLEMS</p>
			</div>
			<ul>

				<?php if(is_array($problem_list) || $problem_list instanceof \think\Collection || $problem_list instanceof \think\Paginator): $i = 0; $__LIST__ = $problem_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li>
					<div class="name clearfix">
						<span>Q</span>
						<h2><?php echo htmlentities($vo['title']); ?></h2>
					</div>
					<div class="content clearfix">
						<span>A</span>
						<div class="text" style="white-space: pre-wrap;word-wrap: break-word; word-break: break-all;"> <?php echo htmlentities($vo['content']); ?> </div>
					</div>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
		<div class="service">
			<div class="title">
				<h2>服务保障</h2>
				<p>SERVICE GUARANTEE</p>
			</div>
			<ul class="clearfix">
				<li>
					<i class="icon"><img src="/assets/index/images/icon13.png"></i>
					<h2>一站式服务理念</h2>
					<p>根据客户的需求，帮助选择合适的空调机型网关</p>
				</li>
				<li>
					<i class="icon"><img src="/assets/index/images/icon14.png"></i>
					<h2>满足个性化服务需求</h2>
					<p>配合客户通过所需要的相关测试，提供相应技术资料</p>
				</li>
				<li>
					<i class="icon"><img src="/assets/index/images/icon15.png"></i>
					<h2>严格的产品质量要求</h2>
					<p>每一种产品都有对应的检测方案和检测标准，对不同客户的产品还会依据客户特殊要求进行检测</p>
				</li>
				<li>
					<i class="icon"><img src="/assets/index/images/icon16.png"></i>
					<h2>积极服务每一位</h2>
					<p>对客户提出的问题24小时内予以解决</p>
				</li>
			</ul>
		</div>
	</div>
</div>
<?php echo widget('Component/footer'); ?>


</body>
</html>


<script>
	$(document).ready(function(){
		$(".problem .name").click(function(){
			$(this).siblings().slideToggle("slow");
			$(this).parent().siblings().children(".content").slideUp("slow");
			$(this).toggleClass("cur");
			$(this).parent().siblings().children(".name").removeClass("cur");
		});
	});
</script>

<script>
    function changePage(obj){
        location.href="<?php echo url('article/solution'); ?>?cid="+$(obj).val()
    }
</script>
