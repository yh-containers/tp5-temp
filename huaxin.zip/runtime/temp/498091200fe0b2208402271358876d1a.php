<?php /*a:2:{s:73:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\article\news.html";i:1563796853;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>




<?php echo widget('Component/header',['act_menu'=>'article/news']); ?>
    <div class="nybanner">
        <p><img src="<?php echo htmlentities($current_cate['img']); ?>"></p>
    </div>
    
    <div class="main">
        <div class="inside_title">
            <h2><?php echo htmlentities($current_cate['name']); ?></h2>
            <p><?php echo htmlentities($current_cate['en']); ?></p>
        </div>
        <div class="inside_sort">
            <select onchange="changePage(this)">
                <?php if(is_array($cate['link_child']) || $cate['link_child'] instanceof \think\Collection || $cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option  value="<?php echo url($vo['url']); ?>" <?php echo $vo['id']==$current_cate['id']?'selected':''; ?>><?php echo htmlentities($vo['name']); ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
        </div>
        <div class="news">
            <div class="news_sort">
                <ul>
                    <?php if(is_array($current_cate['link_child']) || $current_cate['link_child'] instanceof \think\Collection || $current_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $current_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <li class="<?php echo $cid==$vo['id']?'cur':''; ?>"><a href="<?php echo url('',['cid'=>$vo['id']]); ?>"><?php echo htmlentities($vo['name']); ?></a></li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div class="news_list">
                <ul>
                    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <li class="wow fadeInUp">
                        <a href="<?php echo url('newsDetail',['id'=>$vo['id']]); ?>">
                            <div class="img"><img src="<?php echo htmlentities($vo['img']); ?>"></div>
                            <div class="text">
                                <h2><?php echo htmlentities($vo['title']); ?></h2>
                                <p><?php echo htmlentities($vo['intro']); ?></p>
                                <span>查看更多</span>
                            </div>
                            <div class="time">
                                <h2><?php echo substr($vo['show_time'],5,5); ?></h2>
                                <h3><?php echo substr($vo['show_time'],0,4); ?></h3>
                            </div>
                        </a>
                    </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>

                <!--分页-->
                <?php echo $page; ?>
            </div>
        </div>
    </div>

    <div class="footer wrap">
       <p>Copyright © 2019　版权所有　深圳市华新网络能源有限公司 All Rights Reserved 　<a href="http://www.miibeian.gov.cn/">备案号：粤ICP8888888</a></p>
    </div>

<?php echo widget('Component/footer'); ?>


</body>
</html>


<script>
    function changePage(obj){
        location.href=$(obj).val()
    }
</script>
