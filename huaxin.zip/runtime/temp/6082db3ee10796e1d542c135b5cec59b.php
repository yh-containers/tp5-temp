<?php /*a:1:{s:74:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\common\header.html";i:1563797369;}*/ ?>
<div class="header">
    <div class="logo"><a href="index.html"><img src="/assets/m/images/logo.png" alt="" /></a></div>
    <a href="javascript:;" class="sort cl_nav"></a>
    <div class="allnav_left">
        <div class="theclose"><img src="/assets/m/images/close.png" /></div>
        <dl class="left_one">
            <dt class="on <?php echo $act_menu=='index'?'on':''; ?>"><a href="<?php echo url('index/index'); ?>">首页</a></dt>
            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <dt class="<?php echo $act_menu==$vo['url']?'on':$act_menu; ?>"><a href="<?php echo preg_match('/^https?/',$vo['url'])?$vo['url']:url($vo['url']); ?>"><?php echo htmlentities($vo['name']); ?></a></dt>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </dl>
    </div>
    <div class="bk_gray"></div>
    <div class="clearfix"></div>
</div>