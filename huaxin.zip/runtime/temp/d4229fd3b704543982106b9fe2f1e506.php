<?php /*a:2:{s:74:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\article\about.html";i:1563796041;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>




<?php echo widget('Component/header',['act_menu'=>'article/about']); ?>
<div class="nybanner">
    <p><img src="<?php echo htmlentities($current_cate['img']); ?>"></p>
</div>

<div class="main">
        <div class="inside_title">
            <h2><?php echo htmlentities($current_cate['name']); ?></h2>
            <p><?php echo htmlentities($current_cate['en']); ?></p>
        </div>
        <div class="inside_sort">
            <select onchange="changePage(this)">
                <?php if(is_array($cate['link_child']) || $cate['link_child'] instanceof \think\Collection || $cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option  value="<?php echo url($vo['url']); ?>" <?php echo $vo['id']==$current_cate['id']?'selected':''; ?>><?php echo htmlentities($vo['name']); ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
        </div>
        <div class="about">
            <div class="text">
                <?php echo htmlspecialchars_decode($current_cate['content']); ?>
            </div>
            <div class="culture">
                <div class="title">
                    <h2>企业文化</h2>
                    <p>COMPANY CULTURE</p>
                </div>
                <ul class="clearfix">
                    <li>
                        <i class="icon"><img src="/assets/m/images/about01.jpg"></i>
                        <h2>文化理念</h2>
                        <p>品质源于诚信，专业创造价值</p>
                    </li>
                    <li>
                        <i class="icon"><img src="/assets/m/images/about02.jpg"></i>
                        <h2>工作理念</h2>
                        <p>传统匠心品格，细节铸造非凡，专业创造价值</p>
                    </li>
                    <li>
                        <i class="icon"><img src="/assets/m/images/about03.jpg"></i>
                        <h2>用人理念</h2>
                        <p>人格品质和工作能力的和谐统一是能力综合的体现</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="footer wrap">
       <p>Copyright © 2019　版权所有　深圳市华新网络能源有限公司 All Rights Reserved 　<a href="http://www.miibeian.gov.cn/">备案号：粤ICP8888888</a></p>
    </div>


<?php echo widget('Component/footer'); ?>


</body>
</html>


<script>
    function changePage(obj){
        location.href=$(obj).val()
    }
</script>
