<?php /*a:2:{s:76:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\product\add.html";i:1563586172;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\base.html";i:1563530573;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo config('app_name'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/assets/bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="/assets/bower_components/Ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/assets/dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="/assets/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="/assets/layui-v.2.5.4/css/layui.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
<style>
    .intro-block .item{ position: relative; margin-bottom: 10px; }
    .intro-block .item .fa{ position: absolute; top:0; left:0; font-size: 18px;  background: red;color:white;cursor: pointer}
    .intro-block .item input{ padding-left: 40px;}
</style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo url('index/index'); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b><?php echo config('app_name'); ?></b></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b><?php echo config('app_name'); ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- Messages: style can be found in dropdown.less-->
                    <!-- Notifications: style can be found in dropdown.less -->
                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs"><?php echo session('user_name'); ?></span>
                        </a>
                    </li>
                    <!-- Control Sidebar Toggle Button -->
                    <li>
                        <a href="<?php echo url('index/logout'); ?>">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            <span class="hidden-xs">退出登录</span>
                        </a>
                    </li>
                    <li></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">

            </div>
            <!--高亮选中-->
            <?php 
                $current_index = "product,product/index";
                $current_index = empty($current_index)?[]:explode(',', $current_index);
             ?>
            <!-- /.search form -->
           <?php echo widget('Components/menu',['current_index'=>$current_index]); ?>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <!--<section class="content-header">
            <h1>
                404 Error Page
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">404 error</li>
            </ol>
        </section>-->

        <!-- Main content -->
        <section class="content">
            

    <div class="box box-primary">
        <div class="box-header with-border">
            <!--<h3 class="box-title">Quick Example</h3>-->
            <button type="button" onclick="$.common.submitForm()" class="btn  btn-info">保存</button>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
            <div class="box-body">
                <form id="form" action="" class="form-horizontal">
                    <input type="hidden" name="id" value="<?php echo htmlentities($model['id']); ?>"/>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">分类</label>
                        <div class="col-sm-10">
                            <select name="cid" class="form-control">
                                <option value="">请选择分类</option>
                                <?php if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                    <option value="<?php echo htmlentities($vo['id']); ?>"  <?php echo $model['cid']==$vo['id']?'selected':''; ?> ><?php echo htmlentities($vo['name']); ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">名称</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="名称" name="name" value="<?php echo htmlentities($model['name']); ?>" maxlength="100">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">图片</label>
                        <div class="col-sm-10">
                            <input type="hidden" name="img" value="<?php echo htmlentities($model['img']); ?>" />
                            <button type="button" class="layui-btn upload-img" lay-data="{ url: '<?php echo url('upload/upload',['type'=>'product']); ?>', accept: 'images'}">
                                <i class="layui-icon">&#xe67c;</i>图片
                            </button>
                            <img width="80" height="80" src="<?php echo htmlentities($model['img']); ?>" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">排序</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" placeholder="排序" name="sort" value="<?php echo empty($model['sort'])?100:$model['sort']; ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">状态</label>
                        <div class="col-sm-10">
                            <label>
                                <input type="radio" name="status" value="1" <?php echo $model['status']!=2?'checked':''; ?> />
                                正常
                            </label>
                            <label>
                                <input type="radio" name="status" value="2" <?php echo $model['status']==2?'checked':''; ?>>
                                关闭
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">描述</label>
                        <div class="col-sm-10">
                            <textarea name="desc" rows="5" class="form-control"><?php echo htmlentities($model['desc']); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">产品说明</label>
                        <div class="col-sm-10 intro-block">
                            <button type="button"  class="btn  btn-info btn-add-intro" data-ipt_type="textarea">增加文本说明</button>
                            <button type="button"  class="btn  btn-primary btn-add-intro" data-ipt_type="file">增加资源说明</button>
                            <?php 
                                //产品说明
                                $intro = empty($model['intro'])?\app\common\model\Product::$default_intro:$model['intro'];
                             if(is_array($intro) || $intro instanceof \think\Collection || $intro instanceof \think\Paginator): $i = 0; $__LIST__ = $intro;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <div class="item">
                                <i class="fa fa-fw fa-close"></i>
                                <input type="text" class="form-control" name="intro[name][]" value="<?php echo htmlentities($vo['name']); ?>" placeholder="说明标题">
                                <input type="hidden" class="form-control" name="intro[ipt_type][]" value="<?php echo htmlentities($vo['ipt_type']); ?>">
                                <?php if(($vo['ipt_type']=='file')): ?>
                                    <input type="hidden" name="intro[content][]" value="<?php echo htmlentities($vo['content']); ?>" />
                                    <button type="button" class="layui-btn product-intro" lay-data="{ url: '<?php echo url('upload/upload',['type'=>'product-intro']); ?>', accept: 'file'}">
                                        <i class="layui-icon">&#xe67c;</i><?php echo htmlentities($vo['name']); ?>文件
                                    </button>
                                    <a href="<?php echo empty($vo['content'])?'##':$vo['content']; ?>" target="_blank"><?php echo empty($vo['content'])?'未上传':'立即查看'; ?></a>
                                <?php else: ?>
                                    <textarea name="intro[content][]"  rows="5" class="form-control" placeholder="说明内容"><?php echo htmlentities($vo['content']); ?></textarea>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>

                        </div>
                    </div>

                </form>

            </div>
            <!-- /.box-body -->

        <div class="box-footer">

        </div>
    </div>


        </section>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 2.4.0
        </div>
        <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="/assets/bower_components/jquery/dist/jquery.min.js"></script>

<script src="/assets/layui-v.2.5.4/layui.js"></script>

<!-- Bootstrap 3.3.7 -->
<script src="/assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="/assets/bower_components/fastclick/lib/fastclick.js"></script>
<script src="/assets/dist/js/adminlte.min.js"></script>
<script src="/assets/admin/js/common.js"></script>


<script>
    //引用上传组件
    layui.use(['upload'],function(){
        var upload = layui.upload;
        $.common.fileUpload(upload,'.upload-img')
        $.common.fileUpload(upload,'#resource',(res,query_select)=>{
            query_select.prev().val(res.path)
            query_select.parent().find('a').attr('href',res.path).text('立即查看')
        })



        $.common.fileUpload(upload,'.product-intro',(res,query_select)=>{
            query_select.prev().val(res.path)
            query_select.parent().find('a').attr('href',res.path).text('立即查看')
        })

        //移除说明
        $("#form").on('click','.product-intro-new',function(){



        })
        //移除说明
        $("#form").on('click','.intro-block .fa',function(){
            $(this).parent().remove();
        })

        //增加说明
        var upload_intro_url = "{ url: '<?php echo url('upload/upload',['type'=>'product-intro']); ?>', accept: 'file'}";
        $(".btn-add-intro").click(function(){
            var ipt_type = $(this).data('ipt_type')
            var html = '<div class="item">\n' +
                '    <i class="fa fa-fw fa-close"></i>\n' +
                '    <input type="text" class="form-control" name="intro[name][]" placeholder="说明标题" value="">\n' +
                '    <input type="hidden" class="form-control" name="intro[ipt_type][]" value="'+ipt_type+'">\n';

            if(ipt_type==='file'){
                html+= '    <input type="hidden" name="intro[content][]" value="" />\n' +
                    '    <button type="button" class="layui-btn product-intro-new"  lay-data="'+upload_intro_url+'" >\n' +
                    '        <i class="layui-icon">&#xe67c;</i>文件\n' +
                    '    </button>\n'+
                    '    <a href="#" target="_blank">未上传</a>\n';
            }   else{
                html+= '    <textarea name="intro[content][]"  rows="5" class="form-control" placeholder="说明内容"></textarea>\n';
            }
            html+='</div>';
            //插入数据
            $(".intro-block").append(html)
            if(ipt_type==='file'){
                picupload('.product-intro-new')
            }
        })


        function picupload(id) {
            $.common.fileUpload(upload,id,(res,query_select)=>{
                query_select.prev().val(res.path)
                query_select.parent().find('a').attr('href',res.path).text('立即查看')
            })
        }
    })
    $(function(){



    })
</script>


</body>
</html>
