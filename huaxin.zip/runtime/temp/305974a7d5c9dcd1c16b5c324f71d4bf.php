<?php /*a:2:{s:75:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\resource\index.html";i:1563793097;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>




<?php echo widget('Component/header',['act_menu'=>'resource/index']); ?>
    <div class="nybanner">
        <p><img src="<?php echo htmlentities($cate['img']); ?>"></p>
    </div>
    
    <div class="main">
        <div class="inside_title">
            <h2>资料下载</h2>
            <p>DOWNLOAD</p>
        </div>
        <div class="inside_sort">
            <select onchange="s_click(this)">
                <option value="index.html" selected="selected">资料下载</option>
            </select>
        </div>
        <div class="download">
            <div class="download_search">
                <form>
                <input type="search"name="keyword" value="<?php echo htmlentities($keyword); ?>" placeholder="搜索文件名称">
                </form>
            </div>
            <div class="title clearfix">
                <div class="name">文件名称</div>
                <div class="type">文件类型</div>
                <div class="num">下载次数</div>
                <div class="button">下载按钮</div>
            </div>
            <ul>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <li>
                    <div class="name">
                        <i><img src="/assets/m/images/icon20.png"></i>
                        <p><?php echo htmlentities($vo['name']); ?></p>
                    </div>
                    <div class="type"><?php echo htmlentities($vo['type']); ?></div>
                    <div class="num"><?php echo htmlentities($vo['num']); ?></div>
                    <div class="button"><a href="javascript:;" class="opt-down" data-file="<?php echo htmlentities($vo['file']); ?>" data-id="<?php echo htmlentities($vo['id']); ?>"><img src="/assets/m/images/icon21.png"></a></div>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <?php echo $page; ?>
        </div>
    </div>

    <div class="footer wrap">
       <p>Copyright © 2019　版权所有　深圳市华新网络能源有限公司 All Rights Reserved 　<a href="http://www.miibeian.gov.cn/">备案号：粤ICP8888888</a></p>
    </div>

<?php echo widget('Component/footer'); ?>


</body>
</html>


    <script type="text/javascript">
        $(document).ready(function(){
            $(".problem .name").click(function(){
                $(this).siblings().slideToggle("slow");
                $(this).parent().siblings().children(".content").slideUp("slow");
                $(this).toggleClass("cur");
                $(this).parent().siblings().children(".name").removeClass("cur");
            });
        });

        $(function(){
            $(".opt-down").click(function(){
                var $this = $(this)
                var file = $(this).data('file');
                $.get("<?php echo url('recordTimes'); ?>",{id:$(this).data('id')},function(result){
                    $this.parent().prev().text($this.parent().prev().text()-0+1)
                    window.open(file);
                })
            })
        })
    </script>
