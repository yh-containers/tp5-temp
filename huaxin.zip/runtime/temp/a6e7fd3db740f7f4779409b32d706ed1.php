<?php /*a:2:{s:79:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\resource\index.html";i:1563852456;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\base.html";i:1563521072;}*/ ?>
<!DOCTYPE html>
<html lang="CN">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="shortcut icon" href="/assets/index/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/assets/index/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/index/css/css.css"/>
    <script type="text/javascript" src="/assets/index/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/assets/index/js/jquery.SuperSlide.2.1.1.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>


<?php echo widget('Component/header',['act_menu'=>'resource/index']); ?>
	<div class="nybanner">
		<p><img src="<?php echo htmlentities($cate['img']); ?>"></p>
	</div>

<div class="main">
	<div class="inside_top w1200">
		<div class="title">
			<h2>资料下载<span>DOWNLOAD</span></h2>
		</div>
		<div class="column clearfix">
			<ul>
				<li class="cur"><a href="<?php echo url('resource/index'); ?>">资料下载</a></li>
			</ul>
			<div class="bread_crumbs">
				<p>您当前的位置：<a href="<?php echo url('index/index'); ?>">首页</a><span>&gt</span><a href="javascript:;">资料下载</a></p>
			</div>
		</div>
	</div>
	<div class="download w1200">
		<div class="download_search">
			<label>按产品型号搜索：</label>
			<form>
			<input type="search" name="keyword" value="<?php echo htmlentities($keyword); ?>" placeholder="搜索产品型号">
			</form>
		</div>
		<div class="title clearfix">
			<div class="name">文件名称</div>
			<div class="type">文件类型</div>
			<div class="size">文件大小</div>
			<div class="num">下载次数</div>
			<div class="button">下载按钮</div>
		</div>
		<ul>
			<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="wow fadeInUp">
				<div class="name">
					<i><img src="/assets/index/images/icon07.png"></i>
					<p><?php echo htmlentities($vo['name']); ?></p>
				</div>
				<div class="type"><?php echo htmlentities($vo['type']); ?></div>
				<div class="size"><?php echo htmlentities($vo['size']); ?>KB</div>
				<div class="num"><?php echo htmlentities($vo['num']); ?></div>
				<div class="button"><a href="javascript:;" class="opt-down" data-file="<?php echo htmlentities($vo['file']); ?>" data-id="<?php echo htmlentities($vo['id']); ?>"><img src="/assets/index/images/icon08.png"></a></div>
			</li>
			<?php endforeach; endif; else: echo "" ;endif; ?>

		</ul>
		<!--分页-->
		<?php echo $page; ?>
	</div>
</div>
<?php echo widget('Component/footer',['act_menu'=>'product/index']); ?>


</body>
</html>


<script>
	$(function(){
		$(".opt-down").click(function(){
			var $this = $(this)
			var file = $(this).data('file');
			$.get("<?php echo url('recordTimes'); ?>",{id:$(this).data('id')},function(result){
				$this.parent().prev().text($this.parent().prev().text()-0+1)
				window.open(file);
			})
		})
	})
</script>
