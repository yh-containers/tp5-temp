<?php /*a:2:{s:72:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\index\index.html";i:1563865915;s:65:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\m\view\base.html";i:1563593467;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name= "format-detection" content="telephone = no" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="stylesheet" type="text/css" href="/assets/m/css/style.css" />
    <script type="text/javascript" src="/assets/m/js/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/m/js/common.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>



<?php echo widget('Component/header',['act_menu'=>'index']); ?>

<div class="slider-wrap slider-wrap-banner mgtop">
    <div class="swiper-container swiper-container-banner" >
        <div class="swiper-wrapper">
            <?php if(is_array($flow_img) || $flow_img instanceof \think\Collection || $flow_img instanceof \think\Paginator): $i = 0; $__LIST__ = $flow_img;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <div class="swiper-slide"><img src="<?php echo htmlentities($vo['h5_img']); ?>" /></div>
            <?php endforeach; endif; else: echo "" ;endif; ?>

        </div>
        <div class="pagination banner-pagination" id="pagination"></div>
    </div>
</div>
    
    <div class="main">
        <div class="index_pro">
            <div class="index_title">
                <h2>安全、稳定、可信赖的工业物联网产品</h2>
                <p><?php echo htmlentities($product_cate['desc']); ?></p>
            </div>
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <?php if(is_array($product_cate['link_child']) || $product_cate['link_child'] instanceof \think\Collection || $product_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $product_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="swiper-slide">
                        <a href="<?php echo url('product/detail',['id'=>$vo['id']]); ?>">
                            <div class="img"><img src="<?php echo htmlentities($vo['img']); ?>"></div>
                            <div class="text">
                                <h2><?php echo htmlentities($vo['name']); ?></h2>
                                <p><?php echo htmlentities($vo['desc']); ?></p>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
                <!-- Add Arrows -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
        <div class="index_case">
            <div class="index_title">
                <h2>成功案例</h2>
                <p><?php echo htmlentities($case_cate['desc']); ?></p>
            </div>
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <?php if(is_array($case_cate['link_case']) || $case_cate['link_case'] instanceof \think\Collection || $case_cate['link_case'] instanceof \think\Paginator): $i = 0; $__LIST__ = $case_cate['link_case'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$case): $mod = ($i % 2 );++$i;?>
                    <div class="swiper-slide">
                        <a href="<?php echo url('article/casesDetail',['id'=>$vo['id']]); ?>">
                            <div class="img"><img src="<?php echo htmlentities($case['img']); ?>" /></div>
                            <div class="title"><?php echo htmlentities($case['title']); ?></div>
                        </a>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
                <div class="swiper-pagination"></div>

            </div>
        </div>
        <div class="index_solution">
            <div class="index_title">
                <h2>解决方案</h2>
                <p><?php echo htmlentities($solution_cate['desc']); ?></p>
            </div>
            <ul class="clearfix">
                <?php if(is_array($solution_cate['link_child']) || $solution_cate['link_child'] instanceof \think\Collection || $solution_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $solution_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <li>
                    <a href="<?php echo url('article/solution',['id'=>$vo['id']]); ?>">
                        <div class="img"><img src="<?php echo htmlentities($vo['h5_img']); ?>"></div>
                        <div class="text">
                            <i class="icon"><img src="<?php echo htmlentities($vo['icon']); ?>"></i>
                            <div class="name"><?php echo htmlentities($vo['name']); ?></div>
                        </div>
                    </a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <p><a href="<?php echo url('article/solution'); ?>">查看更多解决方案 &gt;</a></p>
        </div>
        <div class="index_news">
            <div class="index_title">
                <h2>新闻资讯</h2>
                <p><?php echo htmlentities($news_cate['desc']); ?></p>
            </div>
            <?php if(is_array($news_cate['link_child']) || $news_cate['link_child'] instanceof \think\Collection || $news_cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $news_cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <ul class="clearfix">
                <?php if(is_array($vo['link_news']) || $vo['link_news'] instanceof \think\Collection || $vo['link_news'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['link_news'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$news): $mod = ($i % 2 );++$i;?>
                <li>
                    <a href="<?php echo url('article/newsDetail',['id'=>$news['id']]); ?>">
                        <div class="img"><img src="<?php echo htmlentities($news['img']); ?>"></div>
                        <div class="text">
                            <h2><?php echo htmlentities($news['title']); ?></h2>
                            <p><?php echo htmlentities($news['intro']); ?></p>
                        </div>
                    </a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <div class="index_about">
            <dl>
                <dt>深圳市华新网络能源有限公司</dt>
                <dd>
                    <p>深圳市华新网络能源有限公司，成立于2014年，是一家集设备能源管控平台、暖通空调自控、工业设备互联、工
                    <p>厂智能等解决方案设计、工程实施、运营管理于一体的综合节能服务商。深圳华新主要业务范围及服务领域包括设备能源管控系统、工业装备互联</p>
                    <p>网接入设备的产品设计开发及智慧工厂解决方案</p> 
                    </p>
                </dd>
            </dl>
            <ul class="clearfix">
                <li>
                    <div class="num"><span>2014</span><em>年</em></div>
                    <p>创建于</p>
                </li>
                <li>
                    <div class="num"><span>3000</span><em>家</em></div>
                    <p>服务客户</p>
                </li>
                <li>
                    <div class="num"><span>99</span><em>%</em></div>
                    <p>好评度</p>
                </li>
                <li>
                    <div class="num"><span>5</span><em>年</em></div>
                    <p>行业经验</p>
                </li>
            </ul>
            <a href="about.html">了解华新智控 &gt;</a>
        </div>
    </div>

    <div class="footer wrap">
       <p>Copyright © 2019　版权所有　深圳市华新网络能源有限公司 All Rights Reserved 　<a href="http://www.miibeian.gov.cn/">备案号：粤ICP8888888</a></p>
    </div>

<?php echo widget('Component/footer',['act_menu'=>'index']); ?>


</body>
</html>


    <link rel="stylesheet" type="text/css" href="/assets/m/css/swiper.min.css">
    <script src="/assets/m/js/swiper-3.4.2.min.js" type="text/javascript"></script>
    <script>
        //banner
        var swiper = new Swiper('.swiper-container-banner',{
        pagination: '.banner-pagination',
        paginationClickable: true,
        loop: true,
        autoplay:3000,
        });

        var swiper = new Swiper('.index_pro .swiper-container', {
            prevButton:'.swiper-button-prev',
            nextButton:'.swiper-button-next',
            autoplay:3000,
            loop: true,
        });

        var swiper = new Swiper('.index_case .swiper-container', {
            pagination: '.swiper-pagination',
            slidesPerView: 2,
            slidesPerGroup:2,
            paginationClickable: true,
            spaceBetween: 10,
            loop: false,
            autoplay:3000,
        });
    </script>

    <!-- 数字跳动 -->
    <script language="javascript" type="text/javascript" src="/assets/m/js/jquery.waypoints.min.js"></script>
    <script type="text/javascript">
        $('.index_about .num span,.index_num .num span').countUp({
            delay: 10,
            time: 2000
        });

    </script>

