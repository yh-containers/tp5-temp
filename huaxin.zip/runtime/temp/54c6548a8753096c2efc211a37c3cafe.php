<?php /*a:2:{s:83:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\article\newsDetail.html";i:1563586172;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\base.html";i:1563521072;}*/ ?>
<!DOCTYPE html>
<html lang="CN">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="shortcut icon" href="/assets/index/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/assets/index/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/index/css/css.css"/>
    <script type="text/javascript" src="/assets/index/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/assets/index/js/jquery.SuperSlide.2.1.1.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<body>


<?php echo widget('Component/header',['act_menu'=>'article/about']); ?>
<div class="nybanner">
	<p><img src="<?php echo htmlentities($current_cate['img']); ?>"></p>
</div>

<div class="main">
	<div class="inside_top w1200">
		<div class="title">
			<h2><?php echo htmlentities($current_cate['name']); ?><span><?php echo htmlentities($current_cate['en']); ?></span></h2>
		</div>
		<div class="column clearfix">
			<ul>
				<?php if(is_array($cate['link_child']) || $cate['link_child'] instanceof \think\Collection || $cate['link_child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $cate['link_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li class="<?php echo $vo['id']==$current_cate['id']?'cur':''; ?>"><a href="<?php echo url($vo['url']); ?>"><?php echo htmlentities($vo['name']); ?></a></li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			<div class="bread_crumbs">
				<p>您当前的位置：<a href="<?php echo url('index/index'); ?>">首页</a><span>&gt;</span><a href="javascript:;"><?php echo htmlentities($current_cate['name']); ?></a></p>
			</div>
		</div>
	</div>
	<div class="news_det w1200">
		<div class="news_title wow fadeInUp">
			<h2><?php echo htmlentities($model['title']); ?></h2>
			<p><span>时间：<?php echo substr($model['update_time'],0,10); ?></span><span>来源：<?php echo htmlentities($model['from']); ?></span><span>浏览：<?php echo htmlentities($model['views']); ?></span></p>
		</div>
		<div class="news_content wow fadeInUp">
			<?php echo htmlspecialchars_decode($model['content']); ?>
		</div>
		<?php echo widget('component/share'); ?>
		<div class="page_turning clearfix wow fadeInUp">
			<div class="page_left">
				<p><a href="<?php echo url('',['id'=>$model_up['id']]); ?>">上一篇：<?php echo htmlentities($model_up['title']); ?></a></p>
				<p><a href="<?php echo url('',['id'=>$model_down['id']]); ?>">下一篇：<?php echo htmlentities($model_down['title']); ?></a></p>
			</div>
			<div class="return_index"><a href="<?php echo url('news'); ?>">返回列表</a></div>
		</div>
	</div>
</div>
<?php echo widget('Component/footer',['act_menu'=>'product/index']); ?>


</body>
</html>



