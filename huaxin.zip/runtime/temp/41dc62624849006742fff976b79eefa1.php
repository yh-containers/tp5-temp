<?php /*a:2:{s:84:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\article\solutionAdd.html";i:1563589493;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\base.html";i:1563530573;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo config('app_name'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/assets/bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="/assets/bower_components/Ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/assets/dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="/assets/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="/assets/layui-v.2.5.4/css/layui.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo url('index/index'); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b><?php echo config('app_name'); ?></b></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b><?php echo config('app_name'); ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- Messages: style can be found in dropdown.less-->
                    <!-- Notifications: style can be found in dropdown.less -->
                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs"><?php echo session('user_name'); ?></span>
                        </a>
                    </li>
                    <!-- Control Sidebar Toggle Button -->
                    <li>
                        <a href="<?php echo url('index/logout'); ?>">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            <span class="hidden-xs">退出登录</span>
                        </a>
                    </li>
                    <li></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">

            </div>
            <!--高亮选中-->
            <?php 
                $current_index = "article,article/solution";
                $current_index = empty($current_index)?[]:explode(',', $current_index);
             ?>
            <!-- /.search form -->
           <?php echo widget('Components/menu',['current_index'=>$current_index]); ?>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <!--<section class="content-header">
            <h1>
                404 Error Page
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">404 error</li>
            </ol>
        </section>-->

        <!-- Main content -->
        <section class="content">
            

    <div class="box box-primary">
        <div class="box-header with-border">
            <!--<h3 class="box-title">Quick Example</h3>-->
        </div>
        <!-- /.box-header -->
        <!-- form start -->
            <div class="box-body">
                <form id="form" action="" class="form-horizontal">
                    <input type="hidden" name="id" value="<?php echo htmlentities($model['id']); ?>"/>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">分类</label>
                        <div class="col-sm-10">
                            <select name="cid" class="form-control">
                                <option value="">请选择分类</option>
                                <?php if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo htmlentities($vo['id']); ?>"  <?php echo $model['cid']==$vo['id']?'selected':''; ?> ><?php echo htmlentities($vo['name']); ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">标题</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="标题" name="title" value="<?php echo htmlentities($model['title']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">作者</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="作者" name="author" value="<?php echo htmlentities($model['author']); ?>"  maxlength="20">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">来源</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="来源" name="from" value="<?php echo htmlentities($model['from']); ?>"  maxlength="20">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">发布时间</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control datetime" placeholder="发布时间" name="show_time" value="<?php echo empty($model['show_time'])?date('Y-m-d H:i:s'):$model['show_time']; ?>" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">封面图</label>
                        <div class="col-sm-10">
                            <input type="hidden" name="img" value="<?php echo htmlentities($model['img']); ?>" />
                            <button type="button" class="layui-btn upload-img" lay-data="{ url: '<?php echo url('upload/upload',['type'=>'article']); ?>', accept: 'images'}">
                                <i class="layui-icon">&#xe67c;</i>封面图
                            </button>
                            <img width="80" height="80" src="<?php echo htmlentities($model['img']); ?>" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">状态</label>
                        <div class="col-sm-10">
                            <label>
                                <input type="radio" name="status" value="1" <?php echo $model['status']!=2?'checked':''; ?> />
                                正常
                            </label>
                            <label>
                                <input type="radio" name="status" value="2" <?php echo $model['status']==2?'checked':''; ?>>
                                关闭
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">简介</label>
                        <div class="col-sm-10">
                            <textarea name="intro" class="form-control" rows="5"><?php echo htmlentities($model['intro']); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">详细内容</label>
                        <div class="col-sm-10">
                            <!-- 加载编辑器的容器 -->
                            <script id="container" name="content" type="text/plain"><?php echo htmlspecialchars_decode($model['content']); ?></script>
                        </div>
                    </div>



                </form>

            </div>
            <!-- /.box-body -->

        <div class="box-footer">
            <button type="button" onclick="$.common.submitForm()" class="col-sm-offset-2 btn  btn-info">保存</button>
        </div>
    </div>


        </section>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 2.4.0
        </div>
        <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="/assets/bower_components/jquery/dist/jquery.min.js"></script>

<script src="/assets/layui-v.2.5.4/layui.js"></script>

<!-- Bootstrap 3.3.7 -->
<script src="/assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="/assets/bower_components/fastclick/lib/fastclick.js"></script>
<script src="/assets/dist/js/adminlte.min.js"></script>
<script src="/assets/admin/js/common.js"></script>


<!-- 配置文件 -->
<script type="text/javascript" src="/assets/ueditor1_4_3_3/ueditor.config.js"></script>
<!-- 编辑器源码文件 -->
<script type="text/javascript" src="/assets/ueditor1_4_3_3/ueditor.all.js"></script>

<script>
    var ue = UE.getEditor('container');
    //引用上传组件
    layui.use(['upload','laydate'],function(){
        var upload = layui.upload;
        var laydate = layui.laydate;
        $.common.fileUpload(upload,'.upload-img')
        //执行一个laydate实例
        laydate.render({
            elem: '.datetime' //指定元素
            ,type: 'datetime' //默认，可不填
            ,max: 1
        });
    })
</script>


</body>
</html>
