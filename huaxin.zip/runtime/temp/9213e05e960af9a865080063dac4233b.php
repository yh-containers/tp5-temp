<?php /*a:2:{s:70:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\error.html";i:1563591200;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\base.html";i:1563521072;}*/ ?>
<!DOCTYPE html>
<html lang="CN">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo config('app_name'); ?></title>
    <meta name="keywords" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_key']); ?>" />
    <meta name="description" content="<?php echo widget('Component/getSysSetting',['type'=>'other','field'=>'meta_desc']); ?>" />
    <link rel="shortcut icon" href="/assets/index/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/assets/index/css/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="/assets/index/css/css.css"/>
    <script type="text/javascript" src="/assets/index/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="/assets/index/js/jquery.SuperSlide.2.1.1.js"></script>
    <meta name="author" content="深圳市深正互联网络有限公司"/>
</head>

<style>
	.error{font-size: 26px;text-align: center;color:orange;padding: 100px;}
</style>

<body>


<?php echo widget('Component/header',['act_menu'=>'index']); ?>
<div class="error"><?php echo htmlentities($msg); ?></div>
<?php echo widget('Component/footer',['act_menu'=>'index']); ?>



</body>
</html>


<script type="text/javascript" src="/assets/index/js/wow.min.js"></script>
<script language="javascript" type="text/javascript" src="/assets/index/js/jquery.waypoints.min.js"></script>



<script type="text/javascript">
	/* banner切换 */
	jQuery(".banner").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click",
	});

	/*产品多页签*/
	jQuery(".pro_list").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold",trigger:"click"});

	/*方案多页签*/
	jQuery(".case_tabs").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold",trigger:"click"});

	/*案例滚动*/
	jQuery(".case_left").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"left",autoPlay:true,vis:4,trigger:"click",scroll:"4"});

	/*新闻多页签*/
	jQuery(".news_tabs").slide({ mainCell:".conWrap", targetCell:".more a", effect:"fold"});
</script>

<script>
	if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
		new WOW().init();
	};
</script>

<!-- 数字跳动 -->
<script type="text/javascript">
	$('.index_about .num span,.index_num .num span').countUp({
		delay: 10,
		time: 2000
	});

</script>
