<?php /*a:2:{s:82:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\system\managerAdd.html";i:1563437444;s:76:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\common\menu.html";i:1563450254;}*/ ?>
<ul class="sidebar-menu" data-widget="tree">
    <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <li class="treeview <?php echo in_array($vo['index'],$current_index)?'menu-open':''; ?>">
            <a href="#">
                <i class="<?php echo htmlentities($vo['icon']); ?>"></i> <span><?php echo htmlentities($vo['name']); ?></span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu" <?php echo in_array($vo['index'],$current_index)?'style="display: block;"':''; ?>>
                <?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$child): $mod = ($i % 2 );++$i;if((!count($child['child']))): ?>
                        <li <?php echo in_array($child['index'],$current_index)?'class="active"':''; ?> ><a href="<?php echo url($child['url']); ?>"><i class="fa fa-circle-o"></i> <?php echo htmlentities($child['name']); ?></a></li>
                    <?php else: ?>
                        <li class="treeview  <?php echo in_array($child['index'],$current_index)?'active menu-open':''; ?>">
                            <a href="#"><i class="fa fa-circle-o"></i> <?php echo htmlentities($child['name']); ?>
                                <span class="pull-right-container">
                                  <i class="fa fa-angle-left pull-right"></i>
                                </span>
                            </a>
                            <ul class="treeview-menu" <?php echo in_array($child['index'],$current_index)?'style="display: block;"':''; ?>>
                                <?php if(is_array($child['child']) || $child['child'] instanceof \think\Collection || $child['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $child['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$re_child): $mod = ($i % 2 );++$i;?>
                                    <li  <?php echo in_array($re_child['index'],$current_index)?'class="active"':''; ?>><a href="<?php echo url($re_child['url']); ?>"><i class="fa fa-circle-o"></i> <?php echo htmlentities($re_child['name']); ?></a></li>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </li>
    <?php endforeach; endif; else: echo "" ;endif; ?>

</ul>