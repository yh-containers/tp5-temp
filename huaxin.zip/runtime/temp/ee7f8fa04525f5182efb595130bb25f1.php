<?php /*a:2:{s:77:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\article\cert.html";i:1563450254;s:69:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\admin\view\base.html";i:1563530573;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo config('app_name'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/assets/bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="/assets/bower_components/Ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/assets/dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="/assets/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="/assets/layui-v.2.5.4/css/layui.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo url('index/index'); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b><?php echo config('app_name'); ?></b></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b><?php echo config('app_name'); ?></b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- Messages: style can be found in dropdown.less-->
                    <!-- Notifications: style can be found in dropdown.less -->
                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="hidden-xs"><?php echo session('user_name'); ?></span>
                        </a>
                    </li>
                    <!-- Control Sidebar Toggle Button -->
                    <li>
                        <a href="<?php echo url('index/logout'); ?>">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            <span class="hidden-xs">退出登录</span>
                        </a>
                    </li>
                    <li></li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">

            </div>
            <!--高亮选中-->
            <?php 
                $current_index = "article,article/cert";
                $current_index = empty($current_index)?[]:explode(',', $current_index);
             ?>
            <!-- /.search form -->
           <?php echo widget('Components/menu',['current_index'=>$current_index]); ?>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <!--<section class="content-header">
            <h1>
                404 Error Page
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">404 error</li>
            </ol>
        </section>-->

        <!-- Main content -->
        <section class="content">
            

    <div class="box box-primary">
        <div class="box-header with-border">
            <a class="layui-btn layui-btn-sm" href="<?php echo url('certAdd'); ?>">添加证书</a>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
            <div class="box-body no-padding">

                <table class="table table-striped" id="layer-photos-demo">
                    <thead>
                    <tr>
                        <th width="80">#</th>
                        <th width="80">名称</th>
                        <th width="100">图片</th>
                        <th width="120">更新日期</th>
                        <th width="80">状态</th>
                        <th width="80">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr>
                        <td><?php echo htmlentities($i); ?></td>
                        <td><?php echo htmlentities($vo['name']); ?></td>
                        <td><img src="<?php echo htmlentities($vo['img']); ?>" width="80" height="80" alt="<?php echo htmlentities($vo['name']); ?>"></td>
                        <td><?php echo htmlentities($vo['update_time']); ?></td>
                        <td><?php echo \app\common\model\Cert::getPropInfo('fields_status',$vo['status']); ?></td>
                        <td>
                            <a class="layui-btn layui-btn-sm" href="<?php echo url('certAdd',['id'=>$vo['id']]); ?>">编辑</a>
                            <a class="layui-btn layui-btn-danger layui-btn-sm" href="javascript:;" onclick="$.common.waitConfirm('是否删除该条数据?','<?php echo url("certDel",["id"=>$vo["id"]]); ?>')" class="ml-5">  删除</a>
                        </td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->

            <div class="box-footer clearfix">
                <?php echo $page; ?>
            </div>
    </div>
    <!-- /.error-page -->

        </section>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 2.4.0
        </div>
        <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="/assets/bower_components/jquery/dist/jquery.min.js"></script>

<script src="/assets/layui-v.2.5.4/layui.js"></script>

<!-- Bootstrap 3.3.7 -->
<script src="/assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="/assets/bower_components/fastclick/lib/fastclick.js"></script>
<script src="/assets/dist/js/adminlte.min.js"></script>
<script src="/assets/admin/js/common.js"></script>


<script>
    layui.use(['layer'],function(){
        layui.layer.photos({
            photos: '#layer-photos-demo'
            ,anim: 5 //0-6的选择，指定弹出图片动画类型，默认随机（请注意，3.0之前的版本用shift参数）
        });
    })
</script>


</body>
</html>
