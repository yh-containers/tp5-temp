<?php /*a:1:{s:82:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\products\products.html";i:1563327467;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>产品中心</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link rel="shortcut icon" href="images/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/css.css"/>
	<script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
	<script type="text/javascript" src="js/jquery.SuperSlide.2.1.1.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<meta name="author" content="深圳市深正互联网络有限公司" />
</head>
<body>
	<div class="header">
		<div class="header_nav w1200 clearfix">
			<div class="logo"><img src="images/logo.png"></div>
			<ul id="nav" class="nav">
				<li class="nLi"><a href="index.html">首页</a></li>
				<li class="nLi"><a href="products.html">产品中心</a></li>
				<li class="nLi"><a href="solution.html">解决方案</a></li>
				<li class="nLi"><a href="download.html">资料下载</a></li>
				<li class="nLi"><a href="case.html">精品案例</a></li>
				<li class="nLi"><a href="about.html">关于华新</a></li>
				<li class="nLi"><a href="support.html">技术支持</a></li>
				<li class="nLi"><a href="javascript:;">在线购买</a></li>
			</ul>
			<div class="search_icon">
				<a href="javascript:;"><img src="images/icon01.png"></a>
				<div class="search">
					<input type="text" class="ssk" name="" placeholder="请输入要搜索的内容">
					<input type="submit" class="ss" name="" value="">
				</div>
			</div>
		</div>
	</div>

	<div class="nybanner">
		<p><img src="images/nybanner01.jpg"></p>
	</div>
	
	<div class="main">
		<div class="inside_top w1200">
			<div class="title wow fadeInUp">
				<h2>产品中心<span>PRODUCTS</span></h2>
			</div>
			<div class="column clearfix wow fadeInUp">
				<ul>
					<li class="cur"><a href="products.html">中央空调网关</a></li>
					<li><a href="products.html">冷水机组网关</a></li>
					<li><a href="products.html">精密空调网关</a></li>
					<li><a href="products.html">仪器仪表采集器</a></li>
				</ul>
				<div class="bread_crumbs">
					<p>您当前的位置：<a href="index.html">首页</a><span>&gt;</span><a href="products.html">产品中心</a><span>&gt;</span><a href="products.html">中央空调网关</a></p>
				</div>
			</div>
		</div>
		<div class="products w1200">
			<div class="partner_list">
				<ul class="clearfix">
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner01.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner02.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner03.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner04.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner05.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner01.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner02.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner03.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner04.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
					<li>
						<a href="javascript:;">
							<div class="img"><img src="images/partner05.jpg"></div>
							<div class="name">合作伙伴</div>
						</a>
					</li>
				</ul>
			</div>
			<div class="products_list">
				<div class="title">
					<h2>格力空调网关<span>Gree gateway</span></h2>
					<div class="pro_search">
						<input type="search" name="" placeholder="请输入空调名称或型号">
						<p><span>热门搜索：</span><a href="">开利30XW</a><a href="">格力gmv</a><a href="">约克YK</a><a href="">大金RXYQ</a></p>
					</div>
				</div>
				<ul class="clearfix">
					<li>
						<a href="products_det.html">
							<div class="img"><img src="images/pro01.jpg"></div>
							<div class="name">格力五代网关<span>&gt;</span></div>
						</a>
					</li>
					<li>
						<a href="products_det.html">
							<div class="img"><img src="images/pro02.jpg"></div>
							<div class="name">格力五代网关<span>&gt;</span></div>
						</a>
					</li>
					<li>
						<a href="products_det.html">
							<div class="img"><img src="images/pro03.jpg"></div>
							<div class="name">格力五代网关<span>&gt;</span></div>
						</a>
					</li>
					<li>
						<a href="products_det.html">
							<div class="img"><img src="images/pro04.jpg"></div>
							<div class="name">格力五代网关<span>&gt;</span></div>
						</a>
					</li>
					<li>
						<a href="products_det.html">
							<div class="img"><img src="images/pro05.jpg"></div>
							<div class="name">格力五代网关<span>&gt;</span></div>
						</a>
					</li>
					<li>
						<a href="products_det.html">
							<div class="img"><img src="images/pro06.jpg"></div>
							<div class="name">格力五代网关<span>&gt;</span></div>
						</a>
					</li>
				</ul>
				<div class="page wow fadeInUp">
					<div class="page_num">
						<a href="" class="first">首页</a>
						<a href="" class="prev">上一页</a>
						<a href="" class="cur2">1</a>
						<a href="">2</a>
						<a href="">3</a>
						<a href="">4</a>
						<a href="" class="next">下一页</a>
						<a href="" class="last">尾页</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="footer">
		<div class="w1200">
			<div class="partner wow fadeInUp">
				<h2>合作伙伴</h2>
				<ul class="clearfix">
					<li><a href=""><img src="images/partner01.jpg"></a></li>
					<li><a href=""><img src="images/partner02.jpg"></a></li>
					<li><a href=""><img src="images/partner03.jpg"></a></li>
					<li><a href=""><img src="images/partner04.jpg"></a></li>
					<li><a href=""><img src="images/partner05.jpg"></a></li>
				</ul>
			</div>
			<div class="footer_sort clearfix wow fadeInUp">
				<dl>
					<dt><a href="solution.html">解决方案</a></dt>
					<dd><a href="solution.html">家庭解决方案</a></dd>
					<dd><a href="solution.html">社区解决方案</a></dd>
				</dl>
				<dl>
					<dt><a href="products.html">产品展示</a></dt>
					<dd><a href="products.html">中央空调网关</a></dd>
					<dd><a href="products.html">冷水机组网关</a></dd>
					<dd><a href="products.html">精密空调网关</a></dd>
					<dd><a href="products.html">AI节能控制箱</a></dd>
				</dl>
				<dl>
					<dt><a href="case.html">精品案例</a></dt>
					<dd><a href="case.html">中央网关案例
					<dd><a href="case.html">冷水机组案例</a></dd>
					<dd><a href="case.html">精密网关案例</a></dd>
					<dd><a href="case.html">AI节能控制案例</a></dd>
				</dl>
				<dl>
					<dt><a href="news.html">新闻资讯</a></dt>
					<dd><a href="news.html">公司新闻</a></dd>
					<dd><a href="news.html">行业资讯</a></dd>
				</dl>
				<dl>
					<dt><a href="about.html">关于我们</a></dt>
					<dd><a href="about.html">公司简介</a></dd>
					<dd><a href="honor.html">资质证书</a></dd>
				</dl>
				<dl>
					<dt><a href="contact.html">联系我们</a></dt>
					<dd><a href="contact.html">联系方式</a></dd>
					<dd><a href="message.html">在线留言</a></dd>
				</dl>
				<div class="footer_ewm">
					<h2>产品资讯热线</h2>
					<p>0755-28718529</p>
					<p><img src="images/ewm.jpg"></p>
					<ul class="clearfix">
						<li><a href=""><img src="images/qq.png"></a></li>
						<li>
							<a href="javascript:;"><img src="images/wx.png"></a>
							<div class="wx_ewm"><img src="images/ewm.jpg"></div>
						</li>
						<li><a href=""><img src="images/wb.png"></a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="footer_copyright">
			<p class="wow fadeInUp">© 2019　版权所有　深圳市华新网络能源有限公司　<a href="http://www.miibeian.gov.cn/">备案号：粤ICP8888888</a>　<a href="https://www.szhulian.com/">技术支持</a></p>
		</div>
	</div>

	<!-- 导航 -->
	<script type="text/javascript">
		var ind = 1; //初始位置
		var nav= jQuery(".nav");
		var init = jQuery(".nav .nLi").eq(ind);
		jQuery("#nav").slide({ 
			type:"menu",
			titCell:".nLi", 
			targetCell:".sub", 
			effect:"slideDown",
			delayTime:300 ,
			triggerTime:0, 
			returnDefault:true,
			defaultIndex:ind
		});	
	</script>

	<script>
		if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
			new WOW().init();
		};
	</script>
</body>
</html>