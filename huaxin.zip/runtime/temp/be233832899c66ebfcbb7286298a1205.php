<?php /*a:2:{s:78:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\product\index.html";i:1563586172;s:78:"D:\phpstudy\PHPTutorial\WWW\tp5-temp\application\index\view\common\header.html";i:1563871824;}*/ ?>
<div class="header">
    <div class="header_nav w1200 clearfix">
        <div class="logo"><img src="/assets/index/images/logo.png"></div>
        <ul id="nav" class="nav">
            <li class="nLi <?php echo $act_menu=='index'?'on':''; ?>"><a href="<?php echo url('index/index'); ?>">首页</a></li>
            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <li class="nLi <?php echo $act_menu==$vo['url']?'on':$act_menu; ?>"><a href="<?php echo preg_match('/^https?/',$vo['url'])?$vo['url']:url($vo['url']); ?>"><?php echo htmlentities($vo['name']); ?></a></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div class="search_icon">
            <a href="javascript:;"><img src="/assets/index/images/icon01.png"></a>
            <div class="search">
                <form action="<?php echo url('product/index'); ?>" method="get">

                <input type="text" class="ssk" name="keyword" value="<?php echo empty($keyword)?'':$keyword; ?>"  placeholder="请输入要搜索的产品">
                    <input type="submit" class="ss" value="">
                </form>
            </div>
        </div>
    </div>
</div>